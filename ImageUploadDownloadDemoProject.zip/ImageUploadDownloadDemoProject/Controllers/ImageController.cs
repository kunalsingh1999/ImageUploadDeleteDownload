﻿using ImageUploadDownloadDemoProject.DBContextSetup;
using ImageUploadDownloadDemoProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;

namespace ImageUploadDownloadDemoProject.Controllers
{
    public class ImageController : Controller
    {
        private readonly ImageUploadDBContext _context;
        private readonly IWebHostEnvironment _hostEnvironment;
        public ImageController(ImageUploadDBContext imageUploadDBContext, IWebHostEnvironment hostEnvironment)
        {
            _context = imageUploadDBContext;
            _hostEnvironment = hostEnvironment;
        }

        public async Task<ActionResult> Index()
        {
            var images = await _context.Images.ToListAsync();
            return View(images);
        }

        public IActionResult UploadImage()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadImage([Bind("ImageId,ImageTitle,ImageFile")] Image image)
        {
            if (!ModelState.IsValid)
            {
                //Save image to wwwroot/image
                string wwwRootPath = _hostEnvironment.WebRootPath;
                string fileName = Path.GetFileNameWithoutExtension(image.ImageFile.FileName);
                string extension = Path.GetExtension(image.ImageFile.FileName);
                image.ImageName = fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
                string path = Path.Combine(wwwRootPath + "/Image/", fileName);
                using (var fileStream = new FileStream(path, FileMode.Create))
                {
                    await image.ImageFile.CopyToAsync(fileStream);
                }
                //Insert record
                _context.Add(image);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(image);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            var image = await _context.Images.FindAsync(id);
            return View(image);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Image image)
        {
            var imageModel = await _context.Images.FindAsync(image.ImageId);
            var imagePath = Path.Combine(_hostEnvironment.WebRootPath, "image", imageModel.ImageName);
            if (System.IO.File.Exists(imagePath))
                System.IO.File.Delete(imagePath);
            _context.Images.Remove(imageModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> DownLoadImage(int? id)
        {
            var image = await _context.Images.FindAsync(id);
            var path=Path.Combine(_hostEnvironment.WebRootPath, "image/"+image?.ImageName);
            var memory = new MemoryStream();
            using (var stream = new FileStream(path, FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }

            memory.Position = 0;
            var contentType = "APPLICATION/octet-stream";
            var fileName=Path.GetFileName(path);
            return File(memory,contentType,fileName);
        }
    }
 }
