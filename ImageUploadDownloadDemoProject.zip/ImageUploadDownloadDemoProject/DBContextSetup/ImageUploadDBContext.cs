﻿using ImageUploadDownloadDemoProject.Models;
using Microsoft.EntityFrameworkCore;

namespace ImageUploadDownloadDemoProject.DBContextSetup
{
    public class ImageUploadDBContext: DbContext
    {
        public ImageUploadDBContext(DbContextOptions<ImageUploadDBContext> options) : base(options){ }

        public DbSet<Image> Images { get; set; }
    }
}
